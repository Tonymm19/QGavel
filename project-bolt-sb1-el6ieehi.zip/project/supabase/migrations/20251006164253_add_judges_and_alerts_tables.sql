/*
  # Add Judges and Alerts Tables

  ## Overview
  Extends the legal case management system with judges tracking and alerts/notifications.

  ## New Tables

  ### 1. `judges`
  Federal and state court judges information
  - `id` (uuid, primary key)
  - `full_name` (text) - Judge's full name
  - `court_name` (text) - Court where judge presides
  - `court_type` (text) - 'federal', 'state', 'district', 'appellate', 'supreme'
  - `division` (text) - Court division or district
  - `email` (text) - Contact email
  - `phone` (text) - Contact phone
  - `address` (text) - Court address
  - `appointment_date` (date) - Date appointed to bench
  - `bio` (text) - Judge biography
  - `procedures` (text) - Special procedures and preferences
  - `availability_notes` (text) - Calendar and scheduling notes
  - `status` (text) - 'active', 'retired', 'senior'
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 2. `alerts`
  System alerts and notifications for users
  - `id` (uuid, primary key)
  - `user_id` (uuid, foreign key) - User receiving alert
  - `case_id` (uuid, foreign key) - Related case (if applicable)
  - `alert_type` (text) - 'deadline', 'rule_update', 'hearing', 'general'
  - `priority` (text) - 'low', 'medium', 'high', 'urgent'
  - `title` (text) - Alert title
  - `message` (text) - Alert message content
  - `is_read` (boolean) - Whether alert has been read
  - `created_at` (timestamptz)

  ### 3. `case_judges`
  Many-to-many relationship between cases and judges
  - `id` (uuid, primary key)
  - `case_id` (uuid, foreign key)
  - `judge_id` (uuid, foreign key)
  - `role` (text) - 'presiding', 'assigned', 'magistrate'
  - `assigned_date` (date)
  - `created_at` (timestamptz)

  ## Security
  RLS policies ensure:
  - Lawyers can view and manage judges
  - Clients can view judges assigned to their cases
  - Users can view their own alerts
  - Lawyers can create and manage case-judge assignments

  ## Indexes
  Performance indexes for foreign keys and frequently queried fields
*/

-- Create judges table
CREATE TABLE IF NOT EXISTS judges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  court_name text NOT NULL,
  court_type text DEFAULT 'district' CHECK (court_type IN ('federal', 'state', 'district', 'appellate', 'supreme')),
  division text,
  email text,
  phone text,
  address text,
  appointment_date date,
  bio text,
  procedures text,
  availability_notes text,
  status text DEFAULT 'active' CHECK (status IN ('active', 'retired', 'senior')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create alerts table
CREATE TABLE IF NOT EXISTS alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  case_id uuid REFERENCES cases(id) ON DELETE CASCADE,
  alert_type text DEFAULT 'general' CHECK (alert_type IN ('deadline', 'rule_update', 'hearing', 'general')),
  priority text DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  title text NOT NULL,
  message text NOT NULL,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create case_judges junction table
CREATE TABLE IF NOT EXISTS case_judges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES cases(id) ON DELETE CASCADE,
  judge_id uuid REFERENCES judges(id) ON DELETE CASCADE,
  role text DEFAULT 'assigned' CHECK (role IN ('presiding', 'assigned', 'magistrate')),
  assigned_date date DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(case_id, judge_id, role)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_judges_court_name ON judges(court_name);
CREATE INDEX IF NOT EXISTS idx_judges_status ON judges(status);
CREATE INDEX IF NOT EXISTS idx_alerts_user_id ON alerts(user_id);
CREATE INDEX IF NOT EXISTS idx_alerts_is_read ON alerts(is_read);
CREATE INDEX IF NOT EXISTS idx_case_judges_case_id ON case_judges(case_id);
CREATE INDEX IF NOT EXISTS idx_case_judges_judge_id ON case_judges(judge_id);

-- Enable RLS
ALTER TABLE judges ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE case_judges ENABLE ROW LEVEL SECURITY;

-- Judges policies
CREATE POLICY "Lawyers can view all judges"
  ON judges FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );

CREATE POLICY "Clients can view judges on their cases"
  ON judges FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM case_judges
      JOIN cases ON cases.id = case_judges.case_id
      JOIN clients ON clients.id = cases.client_id
      WHERE case_judges.judge_id = judges.id
      AND clients.profile_id = auth.uid()
    )
  );

CREATE POLICY "Lawyers can manage judges"
  ON judges FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );

-- Alerts policies
CREATE POLICY "Users can view own alerts"
  ON alerts FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can update own alerts"
  ON alerts FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "System can create alerts"
  ON alerts FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Case judges policies
CREATE POLICY "Users can view case judges for accessible cases"
  ON case_judges FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM cases
      WHERE cases.id = case_judges.case_id
      AND (
        cases.lawyer_id = auth.uid() OR
        cases.client_id IN (SELECT id FROM clients WHERE profile_id = auth.uid()) OR
        EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
      )
    )
  );

CREATE POLICY "Lawyers can manage case judges"
  ON case_judges FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );