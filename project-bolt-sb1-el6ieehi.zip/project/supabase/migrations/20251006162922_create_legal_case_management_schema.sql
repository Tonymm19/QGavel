/*
  # Legal Case Management System - Database Schema

  ## Overview
  This migration creates a comprehensive database schema for a legal case management system
  designed for law firms to manage cases, clients, documents, time tracking, and billing.

  ## New Tables

  ### 1. `profiles`
  User profile information extending Supabase auth.users
  - `id` (uuid, primary key) - Links to auth.users
  - `email` (text) - User email
  - `full_name` (text) - Full legal name
  - `role` (text) - User role: 'lawyer', 'client', 'admin'
  - `firm_name` (text) - Law firm name (for lawyers)
  - `bar_number` (text) - Bar association number (for lawyers)
  - `phone` (text) - Contact phone number
  - `avatar_url` (text) - Profile picture URL
  - `created_at` (timestamptz) - Account creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 2. `clients`
  Client information and contact details
  - `id` (uuid, primary key)
  - `profile_id` (uuid, foreign key) - Links to profiles table
  - `company_name` (text) - Company name (if applicable)
  - `address` (text) - Physical address
  - `city` (text) - City
  - `state` (text) - State/Province
  - `zip_code` (text) - Postal code
  - `notes` (text) - Internal notes about client
  - `status` (text) - 'active', 'inactive', 'archived'
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 3. `cases`
  Legal cases and matters
  - `id` (uuid, primary key)
  - `case_number` (text, unique) - Internal case reference number
  - `title` (text) - Case title/name
  - `client_id` (uuid, foreign key) - Associated client
  - `lawyer_id` (uuid, foreign key) - Assigned lawyer
  - `case_type` (text) - Type: 'civil', 'criminal', 'corporate', 'family', 'real_estate', 'other'
  - `status` (text) - 'open', 'pending', 'closed', 'archived'
  - `priority` (text) - 'low', 'medium', 'high', 'urgent'
  - `court_name` (text) - Court handling the case
  - `judge_name` (text) - Assigned judge
  - `opposing_counsel` (text) - Opposing attorney information
  - `description` (text) - Case description and details
  - `opened_date` (date) - Case opening date
  - `closed_date` (date) - Case closing date (if closed)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 4. `case_deadlines`
  Important dates and deadlines for cases
  - `id` (uuid, primary key)
  - `case_id` (uuid, foreign key) - Associated case
  - `title` (text) - Deadline title
  - `description` (text) - Deadline details
  - `deadline_date` (timestamptz) - Due date and time
  - `deadline_type` (text) - 'filing', 'hearing', 'discovery', 'meeting', 'other'
  - `completed` (boolean) - Whether deadline is met
  - `reminder_sent` (boolean) - Whether reminder was sent
  - `created_by` (uuid, foreign key) - User who created deadline
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 5. `documents`
  Legal documents and files
  - `id` (uuid, primary key)
  - `case_id` (uuid, foreign key) - Associated case
  - `title` (text) - Document title
  - `description` (text) - Document description
  - `document_type` (text) - 'pleading', 'motion', 'evidence', 'contract', 'correspondence', 'other'
  - `file_url` (text) - Storage URL for document
  - `file_size` (bigint) - File size in bytes
  - `file_type` (text) - MIME type
  - `uploaded_by` (uuid, foreign key) - User who uploaded
  - `version` (integer) - Document version number
  - `is_confidential` (boolean) - Confidentiality flag
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 6. `time_entries`
  Billable time tracking for lawyers
  - `id` (uuid, primary key)
  - `case_id` (uuid, foreign key) - Associated case
  - `lawyer_id` (uuid, foreign key) - Lawyer who performed work
  - `date` (date) - Date of work performed
  - `hours` (numeric) - Hours worked (decimal format)
  - `description` (text) - Description of work performed
  - `hourly_rate` (numeric) - Rate charged per hour
  - `billable` (boolean) - Whether time is billable
  - `billed` (boolean) - Whether invoice has been sent
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 7. `case_notes`
  Internal notes and communications about cases
  - `id` (uuid, primary key)
  - `case_id` (uuid, foreign key) - Associated case
  - `author_id` (uuid, foreign key) - Note author
  - `content` (text) - Note content
  - `note_type` (text) - 'general', 'call', 'meeting', 'research', 'strategy'
  - `is_private` (boolean) - Whether note is private to author
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ## Security

  ### Row Level Security (RLS)
  All tables have RLS enabled with the following access patterns:

  1. **Profiles**: Users can view and update their own profile
  2. **Clients**: Lawyers can manage their clients; clients can view their own information
  3. **Cases**: Lawyers can manage cases they're assigned to; clients can view their own cases
  4. **Case Deadlines**: Access tied to case access
  5. **Documents**: Access tied to case access with confidentiality checks
  6. **Time Entries**: Lawyers can manage their own entries; clients can view billed time
  7. **Case Notes**: Access tied to case access with privacy settings

  ## Indexes
  Performance indexes added for:
  - Foreign key relationships
  - Frequently queried fields (status, dates, case_number)
  - Search operations (titles, names)
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text NOT NULL,
  role text NOT NULL DEFAULT 'client' CHECK (role IN ('lawyer', 'client', 'admin')),
  firm_name text,
  bar_number text,
  phone text,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create clients table
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  company_name text,
  address text,
  city text,
  state text,
  zip_code text,
  notes text,
  status text DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'archived')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create cases table
CREATE TABLE IF NOT EXISTS cases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_number text UNIQUE NOT NULL,
  title text NOT NULL,
  client_id uuid REFERENCES clients(id) ON DELETE CASCADE,
  lawyer_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  case_type text DEFAULT 'civil' CHECK (case_type IN ('civil', 'criminal', 'corporate', 'family', 'real_estate', 'other')),
  status text DEFAULT 'open' CHECK (status IN ('open', 'pending', 'closed', 'archived')),
  priority text DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  court_name text,
  judge_name text,
  opposing_counsel text,
  description text,
  opened_date date DEFAULT CURRENT_DATE,
  closed_date date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create case_deadlines table
CREATE TABLE IF NOT EXISTS case_deadlines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES cases(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  deadline_date timestamptz NOT NULL,
  deadline_type text DEFAULT 'other' CHECK (deadline_type IN ('filing', 'hearing', 'discovery', 'meeting', 'other')),
  completed boolean DEFAULT false,
  reminder_sent boolean DEFAULT false,
  created_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create documents table
CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES cases(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  document_type text DEFAULT 'other' CHECK (document_type IN ('pleading', 'motion', 'evidence', 'contract', 'correspondence', 'other')),
  file_url text,
  file_size bigint,
  file_type text,
  uploaded_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  version integer DEFAULT 1,
  is_confidential boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create time_entries table
CREATE TABLE IF NOT EXISTS time_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES cases(id) ON DELETE CASCADE,
  lawyer_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  date date DEFAULT CURRENT_DATE,
  hours numeric(5,2) NOT NULL CHECK (hours > 0),
  description text NOT NULL,
  hourly_rate numeric(10,2) NOT NULL CHECK (hourly_rate >= 0),
  billable boolean DEFAULT true,
  billed boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create case_notes table
CREATE TABLE IF NOT EXISTS case_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES cases(id) ON DELETE CASCADE,
  author_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  note_type text DEFAULT 'general' CHECK (note_type IN ('general', 'call', 'meeting', 'research', 'strategy')),
  is_private boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_clients_profile_id ON clients(profile_id);
CREATE INDEX IF NOT EXISTS idx_clients_status ON clients(status);
CREATE INDEX IF NOT EXISTS idx_cases_client_id ON cases(client_id);
CREATE INDEX IF NOT EXISTS idx_cases_lawyer_id ON cases(lawyer_id);
CREATE INDEX IF NOT EXISTS idx_cases_status ON cases(status);
CREATE INDEX IF NOT EXISTS idx_cases_case_number ON cases(case_number);
CREATE INDEX IF NOT EXISTS idx_case_deadlines_case_id ON case_deadlines(case_id);
CREATE INDEX IF NOT EXISTS idx_case_deadlines_deadline_date ON case_deadlines(deadline_date);
CREATE INDEX IF NOT EXISTS idx_documents_case_id ON documents(case_id);
CREATE INDEX IF NOT EXISTS idx_time_entries_case_id ON time_entries(case_id);
CREATE INDEX IF NOT EXISTS idx_time_entries_lawyer_id ON time_entries(lawyer_id);
CREATE INDEX IF NOT EXISTS idx_case_notes_case_id ON case_notes(case_id);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE cases ENABLE ROW LEVEL SECURITY;
ALTER TABLE case_deadlines ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE time_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE case_notes ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Clients policies
CREATE POLICY "Lawyers can view all clients"
  ON clients FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );

CREATE POLICY "Clients can view own client record"
  ON clients FOR SELECT
  TO authenticated
  USING (profile_id = auth.uid());

CREATE POLICY "Lawyers can manage clients"
  ON clients FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );

-- Cases policies
CREATE POLICY "Lawyers can view assigned cases"
  ON cases FOR SELECT
  TO authenticated
  USING (
    lawyer_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Clients can view own cases"
  ON cases FOR SELECT
  TO authenticated
  USING (
    client_id IN (
      SELECT id FROM clients WHERE profile_id = auth.uid()
    )
  );

CREATE POLICY "Lawyers can manage cases"
  ON cases FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );

-- Case deadlines policies
CREATE POLICY "Users can view deadlines for accessible cases"
  ON case_deadlines FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM cases
      WHERE cases.id = case_deadlines.case_id
      AND (
        cases.lawyer_id = auth.uid() OR
        cases.client_id IN (SELECT id FROM clients WHERE profile_id = auth.uid()) OR
        EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
      )
    )
  );

CREATE POLICY "Lawyers can manage case deadlines"
  ON case_deadlines FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );

-- Documents policies
CREATE POLICY "Users can view documents for accessible cases"
  ON documents FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM cases
      WHERE cases.id = documents.case_id
      AND (
        cases.lawyer_id = auth.uid() OR
        (
          cases.client_id IN (SELECT id FROM clients WHERE profile_id = auth.uid())
          AND documents.is_confidential = false
        ) OR
        EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
      )
    )
  );

CREATE POLICY "Lawyers can manage documents"
  ON documents FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );

-- Time entries policies
CREATE POLICY "Lawyers can view own time entries"
  ON time_entries FOR SELECT
  TO authenticated
  USING (
    lawyer_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Clients can view billed time for their cases"
  ON time_entries FOR SELECT
  TO authenticated
  USING (
    billed = true AND
    case_id IN (
      SELECT id FROM cases
      WHERE client_id IN (SELECT id FROM clients WHERE profile_id = auth.uid())
    )
  );

CREATE POLICY "Lawyers can manage own time entries"
  ON time_entries FOR ALL
  TO authenticated
  USING (
    lawyer_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    lawyer_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Case notes policies
CREATE POLICY "Users can view notes for accessible cases"
  ON case_notes FOR SELECT
  TO authenticated
  USING (
    (is_private = false OR author_id = auth.uid()) AND
    EXISTS (
      SELECT 1 FROM cases
      WHERE cases.id = case_notes.case_id
      AND (
        cases.lawyer_id = auth.uid() OR
        cases.client_id IN (SELECT id FROM clients WHERE profile_id = auth.uid()) OR
        EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
      )
    )
  );

CREATE POLICY "Lawyers can manage case notes"
  ON case_notes FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );