/*
  # Update Clients Table for Standalone Records

  ## Overview
  This migration updates the clients table to store all client information directly,
  without requiring authentication accounts or profile references.

  ## Changes
  1. Add contact fields directly to clients table (full_name, email, phone)
  2. Make profile_id nullable and optional for backwards compatibility
  3. Add unique constraint on email to prevent duplicates

  ## Benefits
  - Clients can be created without auth accounts
  - Simpler data model for client management
  - No sign-up errors or email confirmation issues
*/

-- Add contact fields directly to clients table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'clients' AND column_name = 'full_name'
  ) THEN
    ALTER TABLE clients ADD COLUMN full_name text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'clients' AND column_name = 'email'
  ) THEN
    ALTER TABLE clients ADD COLUMN email text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'clients' AND column_name = 'phone'
  ) THEN
    ALTER TABLE clients ADD COLUMN phone text;
  END IF;
END $$;

-- Add unique constraint on email
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'clients_email_key'
  ) THEN
    ALTER TABLE clients ADD CONSTRAINT clients_email_key UNIQUE (email);
  END IF;
END $$;

-- Create index on email for faster lookups
CREATE INDEX IF NOT EXISTS idx_clients_email ON clients(email);

-- Update RLS policies to work with standalone clients
DROP POLICY IF EXISTS "Lawyers can view all clients" ON clients;
DROP POLICY IF EXISTS "Clients can view own client record" ON clients;
DROP POLICY IF EXISTS "Lawyers can manage clients" ON clients;

-- New policies
CREATE POLICY "Lawyers can view all clients"
  ON clients FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );

CREATE POLICY "Clients with profiles can view own record"
  ON clients FOR SELECT
  TO authenticated
  USING (profile_id = auth.uid());

CREATE POLICY "Lawyers can insert clients"
  ON clients FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );

CREATE POLICY "Lawyers can update clients"
  ON clients FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );

CREATE POLICY "Lawyers can delete clients"
  ON clients FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );