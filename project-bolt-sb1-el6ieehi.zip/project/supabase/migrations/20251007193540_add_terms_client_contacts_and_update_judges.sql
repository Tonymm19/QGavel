/*
  # Add Terms Acceptance, Client Contacts, and Update Judges

  ## Overview
  This migration adds several enhancements:
  1. Terms and conditions acceptance tracking for users
  2. Client contacts table for multiple contacts per client
  3. Updates to judges table structure
  4. Removal of client status field

  ## New Tables

  ### 1. client_contacts
  Multiple contacts for each client
  - id (uuid, primary key)
  - client_id (uuid, foreign key) - Reference to clients table
  - contact_name (text) - Contact person name
  - contact_email (text) - Contact email address
  - contact_phone (text) - Contact phone number
  - is_primary (boolean) - Whether this is the primary contact
  - created_at (timestamptz)
  - updated_at (timestamptz)

  ## Modified Tables

  ### profiles
  - Add terms_accepted (boolean) - Whether user accepted terms
  - Add terms_accepted_at (timestamptz) - When terms were accepted

  ### judges
  - Remove phone and appointment_date fields
  - Remove procedures and availability_notes fields
  - Add courtroom_number (text)
  - Add chambers_number (text)
  - Add courtroom_deputy_name (text)
  - Add courtroom_deputy_phone (text)
  - Add courtroom_deputy_room (text)
  - Add law_clerk_names (text array)

  ### clients
  - Remove status field

  ## Security
  - RLS enabled on client_contacts table
  - Lawyers can manage client contacts
  - Clients can view their own contacts
*/

-- Add terms acceptance fields to profiles
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'terms_accepted'
  ) THEN
    ALTER TABLE profiles ADD COLUMN terms_accepted boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'terms_accepted_at'
  ) THEN
    ALTER TABLE profiles ADD COLUMN terms_accepted_at timestamptz;
  END IF;
END $$;

-- Create client_contacts table
CREATE TABLE IF NOT EXISTS client_contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid REFERENCES clients(id) ON DELETE CASCADE NOT NULL,
  contact_name text NOT NULL,
  contact_email text,
  contact_phone text,
  is_primary boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Update judges table
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'judges' AND column_name = 'phone'
  ) THEN
    ALTER TABLE judges DROP COLUMN phone;
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'judges' AND column_name = 'appointment_date'
  ) THEN
    ALTER TABLE judges DROP COLUMN appointment_date;
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'judges' AND column_name = 'procedures'
  ) THEN
    ALTER TABLE judges DROP COLUMN procedures;
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'judges' AND column_name = 'availability_notes'
  ) THEN
    ALTER TABLE judges DROP COLUMN availability_notes;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'judges' AND column_name = 'courtroom_number'
  ) THEN
    ALTER TABLE judges ADD COLUMN courtroom_number text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'judges' AND column_name = 'chambers_number'
  ) THEN
    ALTER TABLE judges ADD COLUMN chambers_number text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'judges' AND column_name = 'courtroom_deputy_name'
  ) THEN
    ALTER TABLE judges ADD COLUMN courtroom_deputy_name text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'judges' AND column_name = 'courtroom_deputy_phone'
  ) THEN
    ALTER TABLE judges ADD COLUMN courtroom_deputy_phone text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'judges' AND column_name = 'courtroom_deputy_room'
  ) THEN
    ALTER TABLE judges ADD COLUMN courtroom_deputy_room text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'judges' AND column_name = 'law_clerk_names'
  ) THEN
    ALTER TABLE judges ADD COLUMN law_clerk_names text[];
  END IF;
END $$;

-- Remove status field from clients
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'clients' AND column_name = 'status'
  ) THEN
    ALTER TABLE clients DROP COLUMN status;
  END IF;
END $$;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_client_contacts_client_id ON client_contacts(client_id);
CREATE INDEX IF NOT EXISTS idx_client_contacts_is_primary ON client_contacts(is_primary);

-- Enable RLS
ALTER TABLE client_contacts ENABLE ROW LEVEL SECURITY;

-- Client contacts policies
CREATE POLICY "Lawyers can view all client contacts"
  ON client_contacts FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );

CREATE POLICY "Clients can view own client contacts"
  ON client_contacts FOR SELECT
  TO authenticated
  USING (
    client_id IN (
      SELECT id FROM clients WHERE profile_id = auth.uid()
    )
  );

CREATE POLICY "Lawyers can manage client contacts"
  ON client_contacts FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );