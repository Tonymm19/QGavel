/*
  # Add Courts and Case Lawyers Tables

  ## Overview
  This migration enhances the legal case management system by:
  1. Adding a comprehensive courts table with all 94 US District Courts
  2. Creating a many-to-many relationship for lawyers assigned to cases
  3. Updating the cases table to support new fields
  4. Adding opposing counsel contact information

  ## New Tables

  ### 1. courts
  Federal District Courts across the United States
  - id (uuid, primary key)
  - name (text, unique) - Full court name
  - district (text) - District identifier
  - state (text) - State or territory
  - created_at (timestamptz)

  ### 2. case_lawyers
  Many-to-many relationship between cases and lawyers
  - id (uuid, primary key)
  - case_id (uuid, foreign key) - Reference to cases table
  - lawyer_id (uuid, foreign key) - Reference to profiles table
  - role (text) - Lawyer's role: lead, associate, paralegal
  - created_at (timestamptz)

  ## Modified Tables

  ### cases
  - Remove priority field
  - Make opened_date nullable
  - Add court_id foreign key to courts table
  - Add judge_id foreign key to judges table
  - Add opposing_counsel_email and opposing_counsel_phone fields
  - Keep judge_name and opposing_counsel as text fields for backward compatibility

  ## Security
  - RLS enabled on new tables
  - Lawyers and admins can view and manage courts
  - Case lawyers follow same access patterns as cases

  ## Data
  - Pre-populate courts table with all 94 US District Courts
*/

-- Create courts table
CREATE TABLE IF NOT EXISTS courts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  district text NOT NULL,
  state text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create case_lawyers junction table for many-to-many relationship
CREATE TABLE IF NOT EXISTS case_lawyers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid REFERENCES cases(id) ON DELETE CASCADE NOT NULL,
  lawyer_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  role text DEFAULT 'associate' CHECK (role IN ('lead', 'associate', 'paralegal')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(case_id, lawyer_id)
);

-- Add new columns to cases table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'cases' AND column_name = 'court_id'
  ) THEN
    ALTER TABLE cases ADD COLUMN court_id uuid REFERENCES courts(id) ON DELETE SET NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'cases' AND column_name = 'judge_id'
  ) THEN
    ALTER TABLE cases ADD COLUMN judge_id uuid REFERENCES judges(id) ON DELETE SET NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'cases' AND column_name = 'opposing_counsel_email'
  ) THEN
    ALTER TABLE cases ADD COLUMN opposing_counsel_email text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'cases' AND column_name = 'opposing_counsel_phone'
  ) THEN
    ALTER TABLE cases ADD COLUMN opposing_counsel_phone text;
  END IF;
END $$;

-- Remove priority field constraint and make opened_date nullable
DO $$
BEGIN
  ALTER TABLE cases ALTER COLUMN opened_date DROP NOT NULL;
  ALTER TABLE cases ALTER COLUMN opened_date DROP DEFAULT;
  ALTER TABLE cases DROP CONSTRAINT IF EXISTS cases_priority_check;
EXCEPTION
  WHEN OTHERS THEN NULL;
END $$;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_case_lawyers_case_id ON case_lawyers(case_id);
CREATE INDEX IF NOT EXISTS idx_case_lawyers_lawyer_id ON case_lawyers(lawyer_id);
CREATE INDEX IF NOT EXISTS idx_cases_court_id ON cases(court_id);
CREATE INDEX IF NOT EXISTS idx_cases_judge_id ON cases(judge_id);

-- Enable RLS
ALTER TABLE courts ENABLE ROW LEVEL SECURITY;
ALTER TABLE case_lawyers ENABLE ROW LEVEL SECURITY;

-- Courts policies
CREATE POLICY "Lawyers can view all courts"
  ON courts FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );

CREATE POLICY "Admins can manage courts"
  ON courts FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Case lawyers policies
CREATE POLICY "Users can view case lawyers for accessible cases"
  ON case_lawyers FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM cases
      WHERE cases.id = case_lawyers.case_id
      AND (
        cases.lawyer_id = auth.uid() OR
        case_lawyers.lawyer_id = auth.uid() OR
        cases.client_id IN (SELECT id FROM clients WHERE profile_id = auth.uid()) OR
        EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
      )
    )
  );

CREATE POLICY "Lawyers can manage case lawyers"
  ON case_lawyers FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('lawyer', 'admin')
    )
  );

-- Insert all 94 US District Courts
INSERT INTO courts (name, district, state) VALUES
  ('U.S. District Court for the Northern District of Alabama', 'Northern', 'Alabama'),
  ('U.S. District Court for the Middle District of Alabama', 'Middle', 'Alabama'),
  ('U.S. District Court for the Southern District of Alabama', 'Southern', 'Alabama'),
  ('U.S. District Court for the District of Alaska', 'District', 'Alaska'),
  ('U.S. District Court for the District of Arizona', 'District', 'Arizona'),
  ('U.S. District Court for the Eastern District of Arkansas', 'Eastern', 'Arkansas'),
  ('U.S. District Court for the Western District of Arkansas', 'Western', 'Arkansas'),
  ('U.S. District Court for the Northern District of California', 'Northern', 'California'),
  ('U.S. District Court for the Eastern District of California', 'Eastern', 'California'),
  ('U.S. District Court for the Central District of California', 'Central', 'California'),
  ('U.S. District Court for the Southern District of California', 'Southern', 'California'),
  ('U.S. District Court for the District of Colorado', 'District', 'Colorado'),
  ('U.S. District Court for the District of Connecticut', 'District', 'Connecticut'),
  ('U.S. District Court for the District of Delaware', 'District', 'Delaware'),
  ('U.S. District Court for the District of Columbia', 'District', 'District of Columbia'),
  ('U.S. District Court for the Northern District of Florida', 'Northern', 'Florida'),
  ('U.S. District Court for the Middle District of Florida', 'Middle', 'Florida'),
  ('U.S. District Court for the Southern District of Florida', 'Southern', 'Florida'),
  ('U.S. District Court for the Northern District of Georgia', 'Northern', 'Georgia'),
  ('U.S. District Court for the Middle District of Georgia', 'Middle', 'Georgia'),
  ('U.S. District Court for the Southern District of Georgia', 'Southern', 'Georgia'),
  ('U.S. District Court for the District of Hawaii', 'District', 'Hawaii'),
  ('U.S. District Court for the District of Idaho', 'District', 'Idaho'),
  ('U.S. District Court for the Northern District of Illinois', 'Northern', 'Illinois'),
  ('U.S. District Court for the Central District of Illinois', 'Central', 'Illinois'),
  ('U.S. District Court for the Southern District of Illinois', 'Southern', 'Illinois'),
  ('U.S. District Court for the Northern District of Indiana', 'Northern', 'Indiana'),
  ('U.S. District Court for the Southern District of Indiana', 'Southern', 'Indiana'),
  ('U.S. District Court for the Northern District of Iowa', 'Northern', 'Iowa'),
  ('U.S. District Court for the Southern District of Iowa', 'Southern', 'Iowa'),
  ('U.S. District Court for the District of Kansas', 'District', 'Kansas'),
  ('U.S. District Court for the Eastern District of Kentucky', 'Eastern', 'Kentucky'),
  ('U.S. District Court for the Western District of Kentucky', 'Western', 'Kentucky'),
  ('U.S. District Court for the Eastern District of Louisiana', 'Eastern', 'Louisiana'),
  ('U.S. District Court for the Middle District of Louisiana', 'Middle', 'Louisiana'),
  ('U.S. District Court for the Western District of Louisiana', 'Western', 'Louisiana'),
  ('U.S. District Court for the District of Maine', 'District', 'Maine'),
  ('U.S. District Court for the District of Maryland', 'District', 'Maryland'),
  ('U.S. District Court for the District of Massachusetts', 'District', 'Massachusetts'),
  ('U.S. District Court for the Eastern District of Michigan', 'Eastern', 'Michigan'),
  ('U.S. District Court for the Western District of Michigan', 'Western', 'Michigan'),
  ('U.S. District Court for the District of Minnesota', 'District', 'Minnesota'),
  ('U.S. District Court for the Northern District of Mississippi', 'Northern', 'Mississippi'),
  ('U.S. District Court for the Southern District of Mississippi', 'Southern', 'Mississippi'),
  ('U.S. District Court for the Eastern District of Missouri', 'Eastern', 'Missouri'),
  ('U.S. District Court for the Western District of Missouri', 'Western', 'Missouri'),
  ('U.S. District Court for the District of Montana', 'District', 'Montana'),
  ('U.S. District Court for the District of Nebraska', 'District', 'Nebraska'),
  ('U.S. District Court for the District of Nevada', 'District', 'Nevada'),
  ('U.S. District Court for the District of New Hampshire', 'District', 'New Hampshire'),
  ('U.S. District Court for the District of New Jersey', 'District', 'New Jersey'),
  ('U.S. District Court for the District of New Mexico', 'District', 'New Mexico'),
  ('U.S. District Court for the Northern District of New York', 'Northern', 'New York'),
  ('U.S. District Court for the Southern District of New York', 'Southern', 'New York'),
  ('U.S. District Court for the Eastern District of New York', 'Eastern', 'New York'),
  ('U.S. District Court for the Western District of New York', 'Western', 'New York'),
  ('U.S. District Court for the Eastern District of North Carolina', 'Eastern', 'North Carolina'),
  ('U.S. District Court for the Middle District of North Carolina', 'Middle', 'North Carolina'),
  ('U.S. District Court for the Western District of North Carolina', 'Western', 'North Carolina'),
  ('U.S. District Court for the District of North Dakota', 'District', 'North Dakota'),
  ('U.S. District Court for the Northern District of Ohio', 'Northern', 'Ohio'),
  ('U.S. District Court for the Southern District of Ohio', 'Southern', 'Ohio'),
  ('U.S. District Court for the Northern District of Oklahoma', 'Northern', 'Oklahoma'),
  ('U.S. District Court for the Eastern District of Oklahoma', 'Eastern', 'Oklahoma'),
  ('U.S. District Court for the Western District of Oklahoma', 'Western', 'Oklahoma'),
  ('U.S. District Court for the District of Oregon', 'District', 'Oregon'),
  ('U.S. District Court for the Eastern District of Pennsylvania', 'Eastern', 'Pennsylvania'),
  ('U.S. District Court for the Middle District of Pennsylvania', 'Middle', 'Pennsylvania'),
  ('U.S. District Court for the Western District of Pennsylvania', 'Western', 'Pennsylvania'),
  ('U.S. District Court for the District of Puerto Rico', 'District', 'Puerto Rico'),
  ('U.S. District Court for the District of Rhode Island', 'District', 'Rhode Island'),
  ('U.S. District Court for the District of South Carolina', 'District', 'South Carolina'),
  ('U.S. District Court for the District of South Dakota', 'District', 'South Dakota'),
  ('U.S. District Court for the Eastern District of Tennessee', 'Eastern', 'Tennessee'),
  ('U.S. District Court for the Middle District of Tennessee', 'Middle', 'Tennessee'),
  ('U.S. District Court for the Western District of Tennessee', 'Western', 'Tennessee'),
  ('U.S. District Court for the Northern District of Texas', 'Northern', 'Texas'),
  ('U.S. District Court for the Southern District of Texas', 'Southern', 'Texas'),
  ('U.S. District Court for the Eastern District of Texas', 'Eastern', 'Texas'),
  ('U.S. District Court for the Western District of Texas', 'Western', 'Texas'),
  ('U.S. District Court for the District of Utah', 'District', 'Utah'),
  ('U.S. District Court for the District of Vermont', 'District', 'Vermont'),
  ('U.S. District Court for the Eastern District of Virginia', 'Eastern', 'Virginia'),
  ('U.S. District Court for the Western District of Virginia', 'Western', 'Virginia'),
  ('U.S. District Court for the District of the Virgin Islands', 'District', 'Virgin Islands'),
  ('U.S. District Court for the Eastern District of Washington', 'Eastern', 'Washington'),
  ('U.S. District Court for the Western District of Washington', 'Western', 'Washington'),
  ('U.S. District Court for the Northern District of West Virginia', 'Northern', 'West Virginia'),
  ('U.S. District Court for the Southern District of West Virginia', 'Southern', 'West Virginia'),
  ('U.S. District Court for the Eastern District of Wisconsin', 'Eastern', 'Wisconsin'),
  ('U.S. District Court for the Western District of Wisconsin', 'Western', 'Wisconsin'),
  ('U.S. District Court for the District of Wyoming', 'District', 'Wyoming'),
  ('U.S. District Court for the District of Guam', 'District', 'Guam'),
  ('U.S. District Court for the District of the Northern Mariana Islands', 'District', 'Northern Mariana Islands')
ON CONFLICT (name) DO NOTHING;